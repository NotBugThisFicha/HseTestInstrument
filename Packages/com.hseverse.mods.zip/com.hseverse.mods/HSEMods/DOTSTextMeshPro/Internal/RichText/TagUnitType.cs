namespace TextMeshDOTS.RichText
{
    internal enum TagUnitType : byte
    {
        Pixels = 0x0,
        FontUnits = 0x1,
        Percentage = 0x2,
    }
}

