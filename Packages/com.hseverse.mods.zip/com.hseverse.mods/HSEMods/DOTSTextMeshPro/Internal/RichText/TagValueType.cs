namespace TextMeshDOTS.RichText
{
    internal enum TagValueType : byte
    {
        None,
        NumericalValue,
        StringValue,
        ColorValue,
    }
}

