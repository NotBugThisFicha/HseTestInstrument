﻿using Unity.Entities;

namespace HSE.Components
{
    public struct TargetText : IComponentData
    {
        public Entity Entity;
    }
}
