﻿using Unity.Entities;

namespace HSE.Components
{
    public struct LocalInitialized : IComponentData { }
}