﻿using Unity.Entities;

namespace HSE.Components.Transform
{
    public struct RotateToCamera : IComponentData
    {
    }
}
