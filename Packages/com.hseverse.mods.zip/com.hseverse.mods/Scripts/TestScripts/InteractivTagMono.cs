using UnityEngine;

public class InteractivTagMono : MonoBehaviour
{

}
