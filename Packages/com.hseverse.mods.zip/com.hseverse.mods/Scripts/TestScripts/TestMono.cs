using UnityEngine;

public class TestMono : MonoBehaviour
{
    public string Name;
    public int Number;
    public Interactiv[] Interactivs;
}
