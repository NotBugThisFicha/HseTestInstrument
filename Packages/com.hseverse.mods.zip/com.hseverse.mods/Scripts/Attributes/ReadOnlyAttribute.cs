using UnityEngine;

namespace HSE.Editor.Attributes
{
    public sealed class ReadOnlyAttribute : PropertyAttribute { }
}
