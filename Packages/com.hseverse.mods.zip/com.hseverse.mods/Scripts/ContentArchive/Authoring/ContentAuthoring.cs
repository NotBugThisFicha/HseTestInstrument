using UnityEngine;
using static RoomConfigAuthoring;

public class ContentAuthoring : MonoBehaviour
{
    public InteractiveConfig[] roomConfigs;
}
