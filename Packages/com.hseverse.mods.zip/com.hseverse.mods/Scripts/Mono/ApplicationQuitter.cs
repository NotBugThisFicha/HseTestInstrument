using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ApplicationQuitter : MonoBehaviour
{
    public void QuitButton()
    {
        Application.Quit();
    }
}
