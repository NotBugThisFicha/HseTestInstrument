using System;
using Unity.Entities;

[Serializable]
public struct MainEntityCamera : IComponentData
{
}
